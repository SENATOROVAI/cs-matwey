"""Следущие четное."""

num_n: int = int(input())
print(num_n + 2 - num_n % 2)
