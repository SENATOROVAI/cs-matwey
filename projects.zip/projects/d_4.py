"""Количество десятков двухначного числа."""

num_a: int = int(input())
num_b: int = num_a // 10
print(num_b)
