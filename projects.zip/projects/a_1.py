"""Символ или цифра."""

num_a: str = input()
num_i: int = ord(num_a)
if num_i >= 48 and num_i <= 57:
    print("yes.")
else:
    print("no.")
