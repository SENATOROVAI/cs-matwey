list_data = [int(value) for value in input().split()]
print(list_data)
