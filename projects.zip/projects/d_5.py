"""Количество десятков."""

num_a: int = int(input())
num_b: int = (num_a // 10) % 10
print(num_b)
