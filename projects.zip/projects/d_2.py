"""Тоже груши."""

num_n: int = int(input())
num_k: int = int(input())
num_a: int = num_k % num_n
print(num_a)
