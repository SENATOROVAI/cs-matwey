"""Последняя цифра."""

num_a: int = int(input())
num_b: int = num_a % 10
print(num_b)
